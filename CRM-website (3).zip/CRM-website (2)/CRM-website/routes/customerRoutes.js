const express = require("express");
const router = express.Router();
const Customer = require("../models/customer");

// Add customer
router.post("/add", async (req, res) => {
  const customer = new Customer(req.body);
  await customer.save();
  res.send("Customer Added Successfully");
});

// Get all customers
router.get("/", async (req, res) => {
  const customers = await Customer.find();
  res.json(customers);
});

// Update customer
router.put("/:id", async (req, res) => {
  try {
    const updatedCustomer = await Customer.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updatedCustomer);
  } catch (err) {
    res.status(400).send("Error updating customer");
  }
});


// Delete customer
router.delete("/:id", async (req, res) => {
  await Customer.findByIdAndDelete(req.params.id);
  res.send("Customer Deleted");
});

module.exports = router;
