const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  status: {
    type: String,
    enum: ["New", "Old", "Closed"],
    default: "New"   // 👈 automatically sets status to "New"
  }
});

module.exports = mongoose.model("Customer", customerSchema);

